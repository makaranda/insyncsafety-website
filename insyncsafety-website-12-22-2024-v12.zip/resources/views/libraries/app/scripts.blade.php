        <!-- libraries -->
        <script src="{{ url('public/assets/js/vendor/jquery-1.11.1.min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/bootstrap.min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.appear.js') }}"></script>

        <!-- superfish menu  -->
        <script src="{{ url('public/assets/js/vendor/jquery.hoverIntent.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/superfish.js') }}"></script>

        <!-- page scrolling -->
        <script src="{{ url('public/assets/js/vendor/jquery.easing.1.3.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.ui.totop.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.localscroll-min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.scrollTo-min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.parallax-1.1.3.js') }}"></script>

        <!-- widgets -->
        <script src="{{ url('public/assets/js/vendor/jquery.easypiechart.min.js') }}"></script><!-- pie charts -->
        <script src="{{ url('public/assets/js/vendor/jquery.countTo.js') }}"></script><!-- digits counting -->
        <script src="{{ url('public/assets/js/vendor/jquery.prettyPhoto.js') }}"></script><!-- lightbox photos -->
        <script src="{{ url('public/assets/js/vendor/jquery.plugin.min.js') }}"></script><!-- plugin creator for comingsoon counter -->
        <script src="{{ url('public/assets/js/vendor/jquery.countdown.js') }}"></script><!-- coming soon counter -->
        <script src="{{ url('public/assets/js/vendor/jflickrfeed.min.js') }}"></script><!-- flickr -->

        <!-- sliders, filters, carousels -->
        <script src="{{ url('public/assets/js/vendor/jquery.isotope.min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/owl.carousel.min.js') }}"></script>
        <script src="{{ url('public/assets/js/vendor/jquery.flexslider-min.js') }}"></script>
        {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> --}}
        {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script> --}}
        <!-- custom scripts -->
        <script src="{{ url('public/assets/js/plugins.js') }}"></script>
        <script src="{{ url('public/assets/js/parsley.js') }}"></script>
        <!-- Sweet Alert -->
        <script src="{{ url('public/assets/js/sweetalert.min.js')}}"></script>

        <script src="{{ url('public/assets/js/main.js') }}?v={{ date('is') }}"></script>
